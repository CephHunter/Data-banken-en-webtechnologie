SELECT title, [description], country, releaseyear, budget, [image], movie_id
FROM movies
WHERE movie_id = ?