DELETE FROM reviews
WHERE user_id = ? AND movie_id = ?