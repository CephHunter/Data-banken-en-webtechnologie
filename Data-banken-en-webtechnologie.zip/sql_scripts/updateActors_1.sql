INSERT OR IGNORE INTO actors VALUES (
    :actor_id,
    :name,
    :gender,
    :country,
    :year_of_birth,
    :year_of_decease,
    ''
)
