$("document").ready(function() {
    let pageURL = window.location.search.substring(1);
    let URLVariables = pageURL.split('&');
    for (let i = 0; i < URLVariables.length; i++) {
        let param = URLVariables[i].split('=');
        if (param[0] === "aliasSearch") {
            $("#"+param[0]).prop("value", param[1].replace(/\+/g, " "));
        } else {
            $("#"+param[0]).prop("checked", true);
        }
    }
});